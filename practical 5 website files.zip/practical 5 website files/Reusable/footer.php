<?php
    echo '<footer id="footer">
    <p>&copy; Grahamstown Grub Stop</p>

    <a href="https://www.facebook.com/GrubandBarrel/" class="fa fa-facebook"></a>
    <a href ="http://www.twitter.com" class="fa fa-twitter"></a>
    <a href="https://www.youtube.com/watch?v=-9rD2oaqTOQ&t=1s" class="fa fa-youtube"></a>
    <a href="http:///www.instagram.com" class="fa fa-instagram"></a>
    <p id="creators">Created by Litha Mabona, Luke Goodall, Caron Rademan</p>
    <p> email us at <a href="mailto:grahamstowngrubstop@gmail.com">grahamstowngrubstop@gmail.com</a></p>
    <button><a href="#top">&uarr; Back to top</a></button>
  </footer>';
?>